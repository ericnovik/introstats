/*
*******************************************************************************
* Copyright (C) 2010-2012, International Business Machines Corporation and    *
* others. All Rights Reserved.                                                *
*******************************************************************************
*/

#ifndef FMTABLEIMP_H
#define FMTABLEIMP_H


/**
 * @internal
 */
struct FmtStackData {
  DigitList stackDecimalNum;   // 128
  //CharString stackDecimalStr;  // 64
  //                         -----
  //                         192 total
};



#endif
